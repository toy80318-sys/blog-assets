// 토이블록 네이버 블로그 도우미 — 백그라운드
importScripts('features.js', 'comment-core.js', 'rewrite-core.js', 'keystore.js', 'ai-core.js');
// 검색 노출 확인: 글 제목으로 네이버 블로그 검색을 한 번 하고, 결과에 나온 글 순서(블로그ID/글번호)만 돌려줍니다.
const SEARCH_URL = 'https://search.naver.com/search.naver?ssc=tab.blog.all&sm=tab_jum&query=';

async function searchBlog(query) {
  const res = await fetch(SEARCH_URL + encodeURIComponent(String(query).slice(0, 100)), { credentials: 'omit', cache: 'no-store' });
  if (!res.ok) return { ok: false, error: 'HTTP ' + res.status };
  const html = await res.text();
  const re = /https?:\/\/(?:m\.)?blog\.naver\.com\/([A-Za-z0-9_-]+)\/(\d{6,})/g;
  const seen = new Set();
  const list = [];
  let m;
  while ((m = re.exec(html))) {
    const key = m[1].toLowerCase() + '/' + m[2];
    if (!seen.has(key)) { seen.add(key); list.push([m[1], m[2]]); }
  }
  // 결과가 하나도 없을 때: 정말 검색 결과가 없는 경우와, 보안 확인 등으로 결과 페이지가 아닌 경우를 구분합니다
  if (!list.length && !/검색결과가 없습니다|검색 결과가 없습니다/.test(html)) {
    return { ok: false, error: 'unexpected-page' };
  }
  return { ok: true, list };
}

// ───────────── 온라인 업데이트 확인 · 원격 설정(데이터만) ─────────────
// GitHub에 올라간 최신 버전 정보를 1시간마다 확인합니다.
// · 크롬 웹스토어 설치본: 새 버전이 보이면 크롬에 바로 업데이트 확인을 요청하고, 받는 즉시 적용합니다(다운로드·재설치 없음).
//   적용되면 열려 있는 블로그 탭에 새 코드를 넣어, 새로고침 없이 계속 쓸 수 있게 합니다.
// · 폴더(압축 해제) 설치본: 크롬이 코드를 바꿔 주지 않으므로 아이콘에 표시하고, 웹스토어 버전으로 옮기는 방법을 안내합니다.
// 원격 설정은 네이버 버튼 이름 같은 "데이터"만 받으며, 실행 코드는 받지 않습니다.
const REPO_RAW = 'https://raw.githubusercontent.com/toy80318-sys/blog-assets/main/toyblock-extension/update/';
const UPDATE_URL = REPO_RAW + 'version.json';
const CONFIG_URL = REPO_RAW + 'remote-config.json';
const CHECK_EVERY_MIN = 60; // 1시간

const cmpVer = (a, b) => {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0), pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0 ? 1 : -1; }
  return 0;
};
async function installType() {
  try { return (await chrome.management.getSelf()).installType; } catch (_) { return 'unknown'; }
}
async function fetchJson(url) {
  const r = await fetch(url + '?t=' + Date.now(), { cache: 'no-store', credentials: 'omit' });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}
async function checkUpdate() {
  const current = chrome.runtime.getManifest().version;
  const type = await installType();
  const info = { current, installType: type, checkedAt: Date.now() };
  try {
    const v = await fetchJson(UPDATE_URL);
    if (v && typeof v.version === 'string' && /^\d+(\.\d+){0,3}$/.test(v.version)) {
      info.latest = v.version;
      info.notes = typeof v.notes === 'string' ? v.notes.slice(0, 600) : '';
      info.releasedAt = typeof v.released_at === 'string' ? v.released_at : '';
      info.downloadUrl = /^https:\/\/(github\.com|raw\.githubusercontent\.com)\//.test(v.download_url || '') ? v.download_url : '';
      info.guideUrl = /^https:\/\//.test(v.guide_url || '') ? v.guide_url : '';
      info.storeUrl = /^https:\/\/(chromewebstore\.google\.com|chrome\.google\.com\/webstore)\//.test(v.store_url || '') ? v.store_url : '';
      const newer = cmpVer(v.version, current) > 0;
      // 웹스토어 설치(normal)는 크롬에 바로 받아 달라고 요청하고, 폴더 설치본만 아이콘에 표시합니다
      info.available = newer && type !== 'normal';
      if (newer && type === 'normal') info.store = await askStore();
    }
  } catch (e) { info.error = String(e.message || e); }
  try {
    const cfg = await fetchJson(CONFIG_URL);
    if (cfg && typeof cfg === 'object') await chrome.storage.local.set({ nbxRemote: { ...cfg, fetchedAt: Date.now() } });
  } catch (_) { /* 원격 설정은 없어도 됩니다 */ }
  await chrome.storage.local.set({ nbxUpdate: info });
  try {
    await chrome.action.setBadgeText({ text: info.available ? 'N' : '' });
    if (info.available) await chrome.action.setBadgeBackgroundColor({ color: '#e8547a' });
    await chrome.action.setTitle({ title: info.available ? `토이블록 — 새 버전 ${info.latest} 있음` : '토이블록 네이버 블로그 도우미' });
  } catch (_) {}
  autoFolderUpdate(info).catch(() => {});
  return info;
}
// 폴더 설치본 자동 업데이트: 설치 폴더를 한 번 연결해 두었으면, 새 버전이 나왔을 때 업데이트 화면을 뒤쪽 탭으로 열어
// 폴더 허용이 살아 있는 동안은 누르지 않아도 바로 바꿉니다(허용이 없으면 그 화면은 조용히 닫히고 아이콘의 N만 남음).
// 글쓰기 화면이 열려 있으면 미루고, 같은 버전은 12시간에 한 번만 시도합니다.
// 폴더 업데이트 화면이 들어 있는지(웹스토어용 패키지를 폴더로 불러온 경우에는 없음)
const hasFolderUpdater = () => fetch(chrome.runtime.getURL('selfupdate.js'), { method: 'HEAD' }).then((r) => r.ok).catch(() => false);
async function autoFolderUpdate(info) {
  if (!info.available || info.installType !== 'development' || !(await hasFolderUpdater())) return;
  const r = await chrome.storage.local.get(['nbxFolderLink', 'nbxAutoTried']).catch(() => ({}));
  if (!r.nbxFolderLink || !r.nbxFolderLink.linked) return;
  const t = r.nbxAutoTried;
  if (t && t.ver === info.latest && Date.now() - (t.at || 0) < 12 * 3600e3) return;
  const tabs = await chrome.tabs.query({ url: ['https://blog.naver.com/*', 'https://*.blog.naver.com/*'] }).catch(() => []);
  if (tabs.some((x) => /Redirect=Write|PostWriteForm|postwrite|PostUpdateForm|Redirect=Update/i.test(x.url || ''))) return;
  await chrome.storage.local.set({ nbxAutoTried: { ver: info.latest, at: Date.now() } }).catch(() => {});
  await chrome.tabs.create({ url: chrome.runtime.getURL('update.html?go=1&auto=1'), active: false }).catch(() => {});
}
// 웹스토어에 새 버전을 바로 확인해 달라고 요청합니다(너무 자주 부르면 크롬이 잠시 미룹니다: throttled)
async function askStore() {
  if (!chrome.runtime.requestUpdateCheck) return { status: 'unsupported', at: Date.now() };
  try {
    const r = await chrome.runtime.requestUpdateCheck();
    return { status: (r && r.status) || 'unknown', version: (r && r.version) || '', at: Date.now() };
  } catch (e) { return { status: 'error', error: String(e.message || e), at: Date.now() }; }
}
// 새 버전을 다 받으면 곧바로 적용합니다. 적용 뒤(onInstalled)에 열린 탭에 새 코드를 넣습니다.
chrome.runtime.onUpdateAvailable.addListener((d) => {
  chrome.storage.local.set({ nbxApplying: { version: d && d.version, at: Date.now() } }).catch(() => {}).finally(() => chrome.runtime.reload());
});

// 열려 있는 블로그·검색 탭에 지금 버전의 코드를 넣습니다(설치·업데이트 직후 — 새로고침 없이 바로 쓰도록)
// 예전 버전 코드는 features.js의 장치로 스스로 물러나므로 두 번 실행되지 않습니다.
const toRe = (pat) => new RegExp('^' + pat.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$');
async function reinjectAll() {
  const groups = (chrome.runtime.getManifest().content_scripts || []).map((c) => ({ ...c, re: c.matches.map(toRe) }));
  const urls = [...new Set(groups.flatMap((c) => c.matches))];
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: urls }); } catch (_) { return 0; }
  let n = 0;
  for (const t of tabs) {
    if (!t.id || t.discarded || !t.url) continue;
    for (const c of groups) {
      if (!c.re.some((r) => r.test(t.url))) continue;
      const target = { tabId: t.id, allFrames: !!c.all_frames };
      try {
        if (c.css && c.css.length) await chrome.scripting.insertCSS({ target, files: c.css });
        await chrome.scripting.executeScript({ target, files: c.js, injectImmediately: true });
        n++;
      } catch (_) { /* 접근할 수 없는 탭은 건너뜁니다 */ }
    }
  }
  return n;
}

async function handleInstalled(d) {
  chrome.alarms.create('nbx-update', { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 });
  if (d && (d.reason === 'update' || d.reason === 'install')) {
    const to = chrome.runtime.getManifest().version;
    if (d.reason === 'update' && d.previousVersion && d.previousVersion !== to) chrome.storage.local.set({ nbxJustUpdated: { from: d.previousVersion, to, at: Date.now() } }).catch(() => {});
    chrome.storage.local.remove('nbxApplying').catch(() => {});
    await reinjectAll().catch(() => 0);
    // 폴더 설치본을 '지금 업데이트'로 바꿔 넣은 직후: 결과 화면을 다시 엽니다(적용하는 동안 그 화면이 닫히므로)
    // 크롬이 이것을 '업데이트'가 아닌 '설치'로 알릴 때도 있어 두 경우 모두 기록으로 판단합니다
    const r = await chrome.storage.local.get('nbxSelfUpdate').catch(() => ({}));
    const su = r && r.nbxSelfUpdate;
    if (su && Date.now() - (su.at || 0) < 5 * 60e3 && su.to === to) {
      await chrome.storage.local.remove('nbxSelfUpdate').catch(() => {});
      await chrome.storage.local.set({ nbxJustUpdated: { from: su.from, to, at: Date.now(), auto: !!su.auto } }).catch(() => {});
      if (!su.auto) chrome.tabs.create({ url: chrome.runtime.getURL('update.html#done') }).catch(() => {}); // 저절로 바꾼 경우는 화면을 띄우지 않음(팝업에 표시)
    } else if (d.reason === 'install') {
      // 처음 설치: 시작 안내(툴바 고정 · AI 키 연결 · 블로그 열기)를 엽니다
      chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') }).catch(() => {});
    }
  }
  checkUpdate();
}

// '지금 업데이트' 버튼
// · 웹스토어 설치본: 크롬에 바로 새 버전을 확인해 달라고 하고, 받는 즉시 적용합니다(onUpdateAvailable → reload)
// · 폴더 설치본: 업데이트 화면을 열어 설치 폴더에 새 파일을 써 넣고 다시 불러옵니다(처음 한 번만 폴더를 고릅니다)
async function updateNow() {
  const type = await installType();
  if (type === 'normal') {
    const info = await checkUpdate();
    if (!info.store) info.store = await askStore();
    await chrome.storage.local.set({ nbxUpdate: info });
    return { mode: 'store', info };
  }
  if (!(await hasFolderUpdater())) { await chrome.tabs.create({ url: chrome.runtime.getURL('options.html#move') }); return { mode: 'manual' }; }
  await chrome.tabs.create({ url: chrome.runtime.getURL('update.html?go=1') });
  return { mode: 'folder' };
}
chrome.runtime.onInstalled.addListener(handleInstalled);
chrome.runtime.onStartup.addListener(() => { chrome.alarms.create('nbx-update', { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 }); checkUpdate(); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'nbx-update') checkUpdate(); });

// 크롬 단축키(chrome://extensions/shortcuts): 브라우저가 키를 먼저 받으므로 에디터가 키를 가로채도 작동합니다
chrome.commands.onCommand.addListener(async (command, tab) => {
  const m = /^slot-(\d)$/.exec(command);
  if (!m) return;
  if (!tab) [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type: 'nbx-slot', slot: Number(m[1]) - 1 }).catch(() => {});
});

// 확실한 엔터 모드: 크롬 디버거로 실제 키보드와 같은 엔터를 현재 탭에 한 번 넣고 바로 연결을 끊습니다
async function trustedEnter(tabId) {
  if (!chrome.debugger) return { ok: false, error: 'no-permission' };
  const target = { tabId };
  try { await chrome.debugger.attach(target, '1.3'); } catch (e) { return { ok: false, error: 'attach: ' + (e.message || e) }; }
  try {
    const base = { key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13, modifiers: 0 };
    await chrome.debugger.sendCommand(target, 'Input.dispatchKeyEvent', { type: 'keyDown', text: '\r', unmodifiedText: '\r', ...base });
    await chrome.debugger.sendCommand(target, 'Input.dispatchKeyEvent', { type: 'keyUp', ...base });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: 'dispatch: ' + (e.message || e) };
  } finally {
    await chrome.debugger.detach(target).catch(() => {});
  }
}

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (sender.id !== chrome.runtime.id || !msg) return false;
  if (msg.type === 'nbx-search' && typeof msg.query === 'string' && msg.query.trim()) {
    searchBlog(msg.query).then(send, (e) => send({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg.type === 'nbx-trusted-enter' && sender.tab && sender.tab.id) {
    trustedEnter(sender.tab.id).then(send, (e) => send({ ok: false, error: String(e) }));
    return true;
  }
  if (msg.type === 'nbx-check-update') {
    checkUpdate().then(send, (e) => send({ error: String(e) }));
    return true;
  }
  if (msg.type === 'nbx-update-now') {
    updateNow().then(send, (e) => send({ error: String((e && e.message) || e) }));
    return true;
  }
  if (msg.type === 'nbx-open-options') {
    chrome.runtime.openOptionsPage();
    return false;
  }
  if (msg.type === 'nbx-get-commands') {
    chrome.commands.getAll().then((list) => {
      const keys = {};
      list.forEach((c) => { if (/^slot-\d$/.test(c.name) && c.shortcut) keys[c.name] = c.shortcut; });
      send({ keys });
    }, () => send({ keys: {} }));
    return true;
  }
  if (msg.type === 'nbx-relay-slot' && sender.tab && Number.isInteger(msg.slot)) {
    chrome.tabs.sendMessage(sender.tab.id, { type: 'nbx-slot', slot: msg.slot }).catch(() => {});
    return false;
  }
  if (msg.type === 'nbx-open-tips') {
    // 설정에 아임웹 등 팁 페이지 주소가 있으면 그곳으로, 없으면 확장에 들어 있는 팁 페이지로 엽니다
    chrome.storage.sync.get('nbx').then((r) => {
      const custom = r && r.nbx && typeof r.nbx.tipsUrl === 'string' ? r.nbx.tipsUrl.trim() : '';
      const base = /^https?:\/\//i.test(custom) ? custom.split('#')[0] : chrome.runtime.getURL('tips.html');
      const hash = /^[a-z-]{1,20}$/.test(msg.hash || '') ? '#' + msg.hash : '';
      chrome.tabs.create({ url: base + hash });
    });
    return false;
  }
  if (msg.type === 'nbx-open-shortcuts') {
    chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
    return false;
  }
  return false;
});

// ───────────── 이웃 소통 · 댓글 도우미 ─────────────
// 목록에서 글을 누르면 새 탭으로 이동해 댓글창을 열고, 그 글에 맞춘 댓글 초안을 만들어 클립보드에 복사합니다.
// 등록 버튼은 항상 사용자가 직접 누릅니다(확장이 댓글을 대신 등록하지 않습니다).
const ID_RE = /^[A-Za-z0-9_-]{2,40}$/;
const NO_RE = /^\d{6,20}$/;
const CMT_JOB_TTL = 10 * 60e3;
const CACHE_TTL = 30 * 60e3;
const AI_TIMEOUT = 20e3;
const cleanStr = (v, n) => (typeof v === 'string' ? v.replace(/\s+/g, ' ').trim().slice(0, n) : '');
const postKeyOf = (blogId, logNo) => (ID_RE.test(blogId || '') && NO_RE.test(String(logNo || '')) ? blogId.toLowerCase() + '/' + logNo : '');

async function getSettings() {
  try { return NBX.merge((await chrome.storage.sync.get('nbx')).nbx); } catch (_) { return NBX.merge(null); }
}
async function getKeys() {
  try { return await NBXKeys.getAll(); } catch (_) { return {}; }
}

// 작업(탭별): 서비스 워커가 다시 시작돼도 이어지도록 세션 저장소에 둡니다
let jobsP = null;
function loadJobs() {
  if (!jobsP) jobsP = chrome.storage.session.get('nbxCmtJobs').then((r) => r.nbxCmtJobs || {}).catch(() => ({}));
  return jobsP;
}
async function saveJobs() {
  const J = await loadJobs();
  const now = Date.now();
  Object.keys(J).forEach((k) => { if (now - J[k].at > CMT_JOB_TTL) delete J[k]; });
  chrome.storage.session.set({ nbxCmtJobs: J }).catch(() => {});
}
chrome.tabs.onRemoved.addListener(async (tabId) => { const J = await loadJobs(); if (J[tabId]) { delete J[tabId]; saveJobs(); } });

// 기록(열어 본 글·댓글 단 글·등록 시각) — 순서대로 저장해 겹쳐 쓰지 않게 합니다
let logQ = Promise.resolve();
function withLog(fn) {
  logQ = logQ.then(async () => {
    const r = await chrome.storage.local.get('nbxCmtLog').catch(() => ({}));
    const log = r.nbxCmtLog && typeof r.nbxCmtLog === 'object' ? r.nbxCmtLog : {};
    log.posts = log.posts || {}; log.done = Array.isArray(log.done) ? log.done : [];
    const out = fn(log);
    const now = Date.now();
    const keys = Object.keys(log.posts);
    if (keys.length > 1000) keys.sort((a, b) => (log.posts[a].t || 0) - (log.posts[b].t || 0)).slice(0, keys.length - 1000).forEach((k) => delete log.posts[k]);
    log.done = log.done.filter((t) => now - t < 30 * 864e5).slice(-500);
    await chrome.storage.local.set({ nbxCmtLog: log }).catch(() => {});
    return out;
  }).catch(() => {});
  return logQ;
}
function logMark(key, field) {
  if (!key) return Promise.resolve();
  return withLog((log) => { const e = log.posts[key] || {}; e[field] = Date.now(); e.t = Date.now(); log.posts[key] = e; });
}
function statsOf(log) {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const done = (log && log.done) || [];
  return { today: done.filter((t) => t >= start).length, hour: done.filter((t) => Date.now() - t < 3600e3).length, last: done.length ? Math.max(...done) : null };
}
async function readLog() {
  await logQ;
  const r = await chrome.storage.local.get('nbxCmtLog').catch(() => ({}));
  return r.nbxCmtLog || { posts: {}, done: [] };
}

// 저장소를 읽고 고쳐 쓰는 작업은 한 줄로 세워 겹치지 않게 합니다
let storeQ = Promise.resolve();
const serial = (fn) => { const p = storeQ.then(fn, fn); storeQ = p.catch(() => {}); return p; };

// 템플릿 사용 기록: 같은 블로그에 같은 문장이 다시 나오지 않게 합니다
async function usedTemplates(blogId) {
  const r = await chrome.storage.local.get('nbxCmtTpl').catch(() => ({}));
  const u = r.nbxCmtTpl || {};
  return { blog: ((u.blogs || {})[String(blogId || '').toLowerCase()] || []), recent: u.recent || [] };
}
function rememberTemplates(blogId, drafts) { return serial(() => rememberTemplatesNow(blogId, drafts)); }
async function rememberTemplatesNow(blogId, drafts) {
  const ids = drafts.map((d) => d.tplId).filter(Boolean);
  if (!ids.length) return;
  const r = await chrome.storage.local.get('nbxCmtTpl').catch(() => ({}));
  const u = r.nbxCmtTpl || {};
  u.blogs = u.blogs || {};
  const b = String(blogId || '').toLowerCase();
  if (b) u.blogs[b] = [...(u.blogs[b] || []), ...ids].slice(-30);
  const bk = Object.keys(u.blogs);
  if (bk.length > 400) bk.slice(0, bk.length - 400).forEach((k) => delete u.blogs[k]);
  u.recent = [...(u.recent || []), ...ids].slice(-40);
  await chrome.storage.local.set({ nbxCmtTpl: u }).catch(() => {});
}

// 1번(맨 위) 댓글 기록: 바로 앞에 만든 1번 댓글과 같은 댓글이 다시 1번에 오지 않게 합니다(최근 12개)
async function recentTops() {
  const r = await chrome.storage.local.get('nbxCmtTop').catch(() => ({}));
  return Array.isArray(r && r.nbxCmtTop) ? r.nbxCmtTop : [];
}
function rememberTop(d, nick) {
  return serial(async () => {
    const tops = await recentTops();
    tops.push({ n: NBXC.norm(d.text, nick), t: String(d.text).slice(0, 80), id: d.tplId || '', at: Date.now() });
    await chrome.storage.local.set({ nbxCmtTop: tops.slice(-12) }).catch(() => {});
  });
}
// 첫 문장 뼈대(템플릿 문장 ID 중 첫 칭찬 문장)가 같아도 같은 댓글로 봅니다
const headId = (tplId) => { const m = /^v2:[a-z]+:([A-Z]\d+)/.exec(String(tplId || '')); return m ? m[1] : ''; };
function sameAsRecent(d, nick, tops) {
  const n = NBXC.norm(d.text, nick);
  const last = tops.slice(-3); // 바로 앞 세 번의 1번 댓글
  return last.some((x) => x.n === n) || (d.tplId && last.some((x) => x.id && headId(x.id) && headId(x.id) === headId(d.tplId)));
}

// 클립보드: 보이지 않는 offscreen 문서에서 복사합니다(탭 포커스와 관계없이 동작)
let offscreenP = null;
async function ensureOffscreen() {
  try {
    if (chrome.runtime.getContexts) {
      const ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
      if (ctx.length) return;
    }
  } catch (_) {}
  if (!offscreenP) {
    offscreenP = chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['CLIPBOARD'], justification: '댓글 초안을 클립보드에 복사합니다' })
      .catch((e) => { if (!/single offscreen|already/i.test(String(e && e.message))) throw e; })
      .finally(() => { offscreenP = null; });
  }
  return offscreenP;
}
async function copyText(text) {
  if (typeof text !== 'string' || !text) return false;
  try {
    await ensureOffscreen();
    const r = await chrome.runtime.sendMessage({ target: 'nbx-offscreen', type: 'copy', text: text.slice(0, 2000) });
    return !!(r && r.ok);
  } catch (_) { return false; }
}

// ── AI 호출 ──
// AI 호출(aiError · postJson · callAI)은 ai-core.js에 있습니다 — 고쳐 쓰기 화면도 같은 코드를 씁니다
// OpenRouter 기본 모델: 한국어를 잘 쓰는 무료 모델이 지금 있으면 그것을, 없으면 무료 모델 자동 배정(openrouter/free)
const OR_PREFER = ['google/gemma-4-31b-it:free', 'qwen/qwen3.8-27b:free', 'google/gemma-3-27b-it:free', 'meta-llama/llama-3.3-70b-instruct:free', 'openrouter/free'];
async function pickOpenRouterModel() {
  try {
    const r = await fetch('https://openrouter.ai/api/v1/models', { credentials: 'omit', cache: 'no-store' });
    const j = await r.json();
    const ids = new Set(((j && j.data) || []).map((m) => m && m.id).filter((x) => typeof x === 'string'));
    return OR_PREFER.find((id) => ids.has(id)) || 'openrouter/free';
  } catch (_) { return 'openrouter/free'; }
}
async function aiDrafts(provider, apiKey, model, post, cmt) {
  const p = NBXC.buildPrompt(post, { callName: cmt.callName, style: cmt.style, length: cmt.length, avoid: cmt.avoid, mood: cmt.mood });
  const text = await callAI(provider, apiKey, model, p.system, p.user);
  const list = NBXC.parseDrafts(text);
  if (!list.length) throw new Error('응답에서 댓글을 찾지 못했어요');
  return list.map((t) => ({ text: t, source: provider }));
}

function sanitizePost(p, maxBody = 5000) {
  p = p && typeof p === 'object' ? p : {};
  return {
    blogId: ID_RE.test(p.blogId || '') ? p.blogId : '',
    logNo: NO_RE.test(String(p.logNo || '')) ? String(p.logNo) : '',
    title: cleanStr(p.title, 150), nick: cleanStr(p.nick, 30), blogName: cleanStr(p.blogName, 60),
    sections: Array.isArray(p.sections) ? p.sections.map((x) => cleanStr(x, 80)).filter(Boolean).slice(0, 10) : [],
    body: typeof p.body === 'string' ? p.body.slice(0, maxBody) : '',
    images: Number.isFinite(p.images) ? Math.max(0, Math.min(999, p.images)) : undefined
  };
}

// 미리 만든 초안(다음 글) — 한 번 꺼내 쓰면 지웁니다
async function readCache() { const r = await chrome.storage.session.get('nbxCmtCache').catch(() => ({})); return r.nbxCmtCache || {}; }
const sigOf = (cmt, provider) => [provider, NBX.modelOf(cmt, provider), cmt.callName, cmt.style, cmt.length || 'mix'].join('|');
function takeCache(key, sig) {
  if (!key) return Promise.resolve(null);
  return serial(async () => {
    const c = await readCache();
    const e = c[key];
    if (!e) return null;
    delete c[key];
    await chrome.storage.session.set({ nbxCmtCache: c }).catch(() => {});
    return e.sig === sig && Date.now() - e.at < CACHE_TTL && Array.isArray(e.drafts) && e.drafts.length ? e.drafts : null;
  });
}
function putCache(key, sig, drafts) { return serial(() => putCacheNow(key, sig, drafts)); }
async function putCacheNow(key, sig, drafts) {
  const c = await readCache();
  c[key] = { sig, drafts, at: Date.now() };
  const ks = Object.keys(c).sort((a, b) => c[a].at - c[b].at);
  while (ks.length > 10) delete c[ks.shift()];
  await chrome.storage.session.set({ nbxCmtCache: c }).catch(() => {});
}

const safeCp = (n) => (n > 0 && n <= 0x10ffff && !(n >= 0xd800 && n <= 0xdfff) ? String.fromCodePoint(n) : '');
const decodeEnt = (s) => String(s || '').replace(/&#(\d{1,8});/g, (_, n) => safeCp(+n)).replace(/&#x([0-9a-f]{1,8});/gi, (_, n) => safeCp(parseInt(n, 16)))
  .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&');
// 글자 사이의 꾸밈 태그(<b>·<mark>)는 붙여서, 문단·줄 태그는 띄어서 없앱니다
const stripTags = (h) => decodeEnt(String(h || '').replace(/<(script|style)\b[\s\S]*?<\/\1>/gi, ' ').replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|li|h[1-6]|tr)>/gi, '\n').replace(/<\/?(p|div|li|ul|ol|h[1-6]|tr|td|th|table|section|article|img)\b[^>]*>/gi, ' ').replace(/<[^>]+>/g, '')).replace(/[ \t ]+/g, ' ').replace(/\s*\n\s*/g, '\n').trim();

// 다음 글 미리 읽기: 글 화면(PostView)을 받아 제목·닉네임·본문만 대략 뽑습니다
function parsePostHtml(html, blogId, logNo, maxBody = 5000) {
  const meta = (prop) => { const m = html.match(new RegExp(`<meta[^>]+property=["']${prop}["'][^>]+content=(?:"([^"]*)"|'([^']*)')`, 'i')); return m ? decodeEnt(m[1] != null ? m[1] : m[2]) : ''; };
  // 본문 시작: 스마트에디터 ONE(se-main-container) · 3.0(se_component_wrap) · 2.0(postViewArea) · 글 번호 영역 순서로 찾고, 댓글 영역 앞에서 자릅니다
  let i = -1;
  for (const mark of ['se-main-container', 'se_component_wrap', 'id="postViewArea"', `id="post-view${logNo}"`]) { i = html.indexOf(mark); if (i >= 0) break; }
  let region = i >= 0 ? html.slice(i, i + 80000) : '';
  const cut = region.search(/(id|class)=["'][^"']*(area_comment|naverComment|post_footer_contents|wrap_postcomment|comment_area)/);
  if (cut > 200) region = region.slice(0, cut);
  const sections = [];
  const sre = /se-sectionTitle[\s\S]{0,600}?se-text-paragraph[^>]*>([\s\S]*?)<\/p>/g;
  let m;
  while ((m = sre.exec(region)) && sections.length < 8) { const t = stripTags(m[1]); if (t) sections.push(t); }
  const images = (region.match(/se-image-resource|class=["'][^"']*se_mediaImage|<img\b/g) || []).length;
  const post = sanitizePost({ blogId, logNo, title: meta('og:title'), nick: meta('naverblog:nickname'), sections, body: stripTags(region).slice(0, maxBody) }, maxBody);
  post.images = images;
  return post;
}
async function fetchPostLite(blogId, logNo) {
  const r = await fetch(`https://blog.naver.com/PostView.naver?blogId=${encodeURIComponent(blogId)}&logNo=${logNo}&redirect=Dlog&widgetTypeCall=true&directAccess=false`, { credentials: 'include', cache: 'no-store' });
  if (!r.ok) return null;
  const html = await r.text();
  return parsePostHtml(html, blogId, logNo);
}
// ── 누락·주의 글 고쳐 쓰기: 글을 읽고, 글쓰기 지침(설정에서 바꿀 수 있음)과 진단을 붙여 AI에게 다시 쓰게 합니다
async function rewritePost(msg) {
  if (!ID_RE.test(msg.blogId || '') || !NO_RE.test(String(msg.logNo || ''))) return { ok: false, error: 'bad-id' };
  const r = await fetch(`https://blog.naver.com/PostView.naver?blogId=${encodeURIComponent(msg.blogId)}&logNo=${msg.logNo}&redirect=Dlog&widgetTypeCall=true&directAccess=false`, { credentials: 'include', cache: 'no-store' }).catch(() => null);
  if (!r || !r.ok) return { ok: false, error: 'read', detail: r ? 'HTTP ' + r.status : 'network' };
  const post = parsePostHtml(await r.text(), msg.blogId, String(msg.logNo), 12000);
  if (!post.title && !post.body) return { ok: false, error: 'read' };
  const g = (await chrome.storage.local.get('nbxRewriteGuide').catch(() => ({}))).nbxRewriteGuide;
  const diag = { status: msg.status === 'warn' ? 'warn' : 'miss', rank: Number(msg.rank) || null, tag: cleanStr(msg.tag, 20), query: post.title };
  const prompt = NBXR.buildRewrite(post, diag, typeof g === 'string' ? g : '');
  const s = await getSettings();
  const prov = s.cmt.provider;
  const info = { post: { title: post.title, chars: String(post.body || '').replace(/\s/g, '').length, sections: post.sections }, prompt, customGuide: !!(typeof g === 'string' && g.trim()) };
  if (info.post.chars < 80) return { ok: false, error: 'empty-body', ...info }; // 본문을 거의 읽지 못한 글은 제목만으로 새로 쓰지 않음
  if (msg.promptOnly) return { ok: true, ...info };
  if (prov === 'template') return { ok: false, error: 'no-ai', ...info };
  if (!(await getKeys())[prov]) return { ok: false, error: 'no-key', provider: NBX.AI_PROVIDERS[prov].label, ...info };
  // AI 호출은 고쳐 쓰기 화면이 직접 합니다(답이 30초 넘게 걸릴 수 있어 서비스 워커에서 부르지 않음)
  return { ok: true, ready: true, provider: prov, providerLabel: NBX.AI_PROVIDERS[prov].label, model: NBX.modelOf(s.cmt, prov), ...info };
}

// ── 삭제·비공개 글 거르기: 글 화면을 한 번 읽어, 지워졌거나 볼 수 없는 글이면 30일 동안 기억하고 추천·열기에서 뺍니다
// 확인하지 못했을 때(네트워크 오류 등)는 그대로 둡니다 — 확실히 지워진 글만 뺍니다
const DEAD_RE = /(존재하지\s*않는\s*(게시물|게시글|글|포스트|페이지)|삭제되었거나|삭제된\s*(게시물|게시글|글|포스트)|(게시물|게시글|글)이\s*삭제|찾을\s*수\s*없는\s*(게시물|게시글|글|포스트))/;
// 비공개·이웃공개·로그인 필요: 지금은 댓글을 달 수 없지만 나중에(로그인·이웃이 된 뒤) 볼 수 있으니 오래 기억하지 않습니다
const LOCKED_RE = /(비공개\s*(게시물|게시글|글|포스트)|접근\s*권한이\s*없|볼\s*수\s*없는\s*(게시물|게시글|글)|이웃(만|에게만)\s*공개|서로이웃(만|에게만)\s*공개|로그인이\s*필요)/;
const POST_BODY_RE = /se-main-container|id=["']postViewArea|id=["']post-view\d|se_component_wrap|__se_component_area/;
const DEAD_DAYS = 30;
const aliveMem = new Map();
async function readDead() {
  const r = await chrome.storage.local.get('nbxDeadPosts').catch(() => ({}));
  const D = (r && r.nbxDeadPosts) || {};
  const cut = Date.now() - DEAD_DAYS * 864e5;
  Object.keys(D).forEach((k) => { if (D[k] < cut) delete D[k]; });
  return D;
}
function markDead(key) { return serial(() => markDeadNow(key)); } // 동시에 여러 글을 기록해도 서로 덮어쓰지 않게
async function markDeadNow(key) {
  const D = await readDead();
  D[key] = Date.now();
  const keys = Object.keys(D);
  if (keys.length > 1000) keys.sort((a, b) => D[a] - D[b]).slice(0, keys.length - 1000).forEach((k) => delete D[k]);
  await chrome.storage.local.set({ nbxDeadPosts: D }).catch(() => {});
}
async function postAlive(blogId, logNo) {
  const key = postKeyOf(blogId, logNo);
  if (!key) return true;
  if ((await readDead())[key]) return false;
  const c = aliveMem.get(key);
  if (c && Date.now() - c.at < 6 * 3600e3) return c.ok;
  let ok = true;
  try {
    const r = await fetch(`https://blog.naver.com/PostView.naver?blogId=${encodeURIComponent(blogId)}&logNo=${logNo}&redirect=Dlog&widgetTypeCall=true&directAccess=false`, { credentials: 'include', cache: 'no-store', signal: AbortSignal.timeout(8000) });
    if (r.status === 404 || r.status === 410) ok = false;
    else if (r.ok) {
      const html = await r.text();
      const plain = stripTags(html).slice(0, 20000);
      if (!POST_BODY_RE.test(html) && (DEAD_RE.test(plain) || DEAD_RE.test(html.slice(0, 60000)))) ok = false; // 안내가 alert 스크립트 안에 있어도 알아봄
      else if (!POST_BODY_RE.test(html) && (LOCKED_RE.test(plain) || LOCKED_RE.test(html.slice(0, 60000)))) { aliveMem.set(key, { ok: false, at: Date.now(), locked: true }); return false; }
      else if (POST_BODY_RE.test(html)) { try { const post = parsePostHtml(html, blogId, String(logNo)); if (post.title || post.body) { aliveMem.set(key, { ok: true, at: Date.now(), post }); return true; } } catch (_) {} }
    }
  } catch (_) { ok = true; }
  aliveMem.set(key, { ok, at: Date.now() });
  if (aliveMem.size > 500) aliveMem.delete(aliveMem.keys().next().value);
  if (!ok) await markDead(key);
  return ok;
}
// 목록의 글들을 한꺼번에(동시에 4개씩) 확인해 지워진 글의 키를 돌려줍니다
async function aliveCheck(items) {
  const list = (Array.isArray(items) ? items : []).filter((x) => x && ID_RE.test(x.blogId || '') && NO_RE.test(String(x.logNo || ''))).slice(0, 60);
  const dead = [];
  let i = 0;
  const moods = {};
  const s = await getSettings();
  const worker = async () => {
    while (i < list.length) {
      const x = list[i++];
      const key = postKeyOf(x.blogId, x.logNo);
      if (!(await postAlive(x.blogId, String(x.logNo)))) { dead.push(key); continue; }
      // 글을 읽었으면 분위기를 나누고, 그 분위기에 맞는 템플릿 댓글을 미리 만들어 둡니다(열면 바로 씀)
      const c = aliveMem.get(key);
      if (c && c.post) {
        const post = { ...c.post, nick: c.post.nick || cleanStr(x.nick, 30), title: c.post.title || cleanStr(x.title, 150) };
        const mood = NBXC.classify(post);
        let first = '';
        try {
          const drafts = NBXC.compose(post, { callName: s.cmt.callName, relation: x.relation === 'buddy' ? 'buddy' : 'other', length: s.cmt.length, mood }, await usedTemplates(post.blogId));
          await putPrepared(key, { mood, drafts, sig: sigOf(s.cmt, 'template') });
          first = drafts[0] ? drafts[0].text : '';
        } catch (_) {}
        moods[key] = { tone: mood.tone, sub: mood.sub || '', label: mood.label, topic: mood.topic || '', topicLabel: mood.topicLabel || '', first };
      }
    }
  };
  await Promise.all([worker(), worker(), worker(), worker()]);
  return { ok: true, dead, moods };
}
// 미리 준비한 댓글(세션에만, 최근 60개)
async function readPrepared() { const r = await chrome.storage.session.get('nbxPrepared').catch(() => ({})); return (r && r.nbxPrepared) || {}; }
function putPrepared(key, v) {
  return serial(async () => {
    const P = await readPrepared();
    P[key] = { ...v, at: Date.now() };
    const ks = Object.keys(P).sort((a, b) => P[a].at - P[b].at);
    while (ks.length > 60) delete P[ks.shift()];
    await chrome.storage.session.set({ nbxPrepared: P }).catch(() => {});
  });
}
function takePrepared(key) {
  return serial(async () => {
    const P = await readPrepared();
    const e = P[key];
    if (!e) return null;
    delete P[key];
    await chrome.storage.session.set({ nbxPrepared: P }).catch(() => {});
    return Date.now() - e.at < 3 * 3600e3 ? e : null;
  });
}

async function prefetch(next) {
  let mine = '';
  try {
    if (!next || !ID_RE.test(next.blogId || '') || !NO_RE.test(String(next.logNo || ''))) return;
    const s = await getSettings();
    const prov = s.cmt.provider;
    if (!s.cmt.prefetch || prov === 'template') return;
    const apiKey = (await getKeys())[prov];
    if (!apiKey) return;
    const key = postKeyOf(next.blogId, next.logNo);
    if ((await readCache())[key] || prefetching.has(key)) return;
    prefetching.add(key); mine = key; // 이 호출이 표시한 것만 이 호출이 지웁니다
    const post = await fetchPostLite(next.blogId, String(next.logNo));
    if (!post || (!post.body && !post.title)) return;
    post.title = post.title || cleanStr(next.title, 150);
    post.nick = post.nick || cleanStr(next.nick, 30);
    const drafts = await aiDrafts(prov, apiKey, NBX.modelOf(s.cmt, prov), post, { ...s.cmt, relation: next.relation, mood: NBXC.classify(post) });
    await putCache(key, sigOf(s.cmt, prov), drafts);
  } catch (_) { /* 미리 만들기는 실패해도 됩니다 — 글을 열 때 다시 만듭니다 */ }
  finally { if (mine) prefetching.delete(mine); }
}
const prefetching = new Set();

async function cmtGenerate(msg) {
  const s = await getSettings();
  const c = s.cmt;
  const post = sanitizePost(msg.post);
  const key = postKeyOf(post.blogId, post.logNo);
  const want = msg.mode === 'template' ? 'template' : c.provider;
  let drafts = [], provider = 'template', note = '';
  // 글 분위기: 지금 연 글의 내용으로 다시 나눕니다(목록에서 미리 나눈 결과보다 정확)
  const mood = NBXC.classify(post);
  const prepared = key ? await takePrepared(key) : null;
  if (want !== 'template') {
    const info = NBX.AI_PROVIDERS[want];
    const apiKey = (await getKeys())[want];
    if (!apiKey) note = `${info.label} API 키가 없어 템플릿으로 만들었어요. 설정에서 키를 넣으면 AI가 글을 읽고 만들어요.`;
    else {
      const cached = msg.regen ? null : await takeCache(key, sigOf(c, want));
      if (cached) { drafts = cached; provider = want; }
      else {
        try { drafts = await aiDrafts(want, apiKey, NBX.modelOf(c, want), post, { ...c, relation: msg.relation, mood, avoid: (await recentTops()).slice(-3).map((x) => x.t) }); provider = want; }
        catch (e) { note = `${info.label} 연결에 실패해 템플릿으로 만들었어요. (${cleanStr(String(e && e.message || e), 120)})`; }
      }
    }
  }
  const used = await usedTemplates(post.blogId);
  const tops = await recentTops();
  used.recent = [...(used.recent || []), ...tops.map((x) => x.id).filter(Boolean)];
  let fromPrepared = false;
  if (!drafts.length && !msg.regen && prepared && prepared.sig === sigOf(c, 'template') && prepared.mood && prepared.mood.tone === mood.tone && Array.isArray(prepared.drafts) && prepared.drafts.length === 3) {
    drafts = prepared.drafts.map((d) => ({ ...d })); fromPrepared = true;
    await rememberTemplates(post.blogId, drafts);
  }
  if (drafts.length < 3) {
    const extra = NBXC.compose(post, { callName: c.callName, relation: msg.relation, length: c.length, mood }, used).slice(0, 3 - drafts.length);
    drafts = drafts.concat(extra);
    if (provider === 'template') drafts = drafts.slice(0, 3);
    await rememberTemplates(post.blogId, extra);
  }
  // 맨 위(1번) 댓글이 최근 1번 댓글과 같으면 다른 초안을 1번으로 올리고, 셋 다 같으면 템플릿으로 새로 만듭니다
  if (drafts.length && sameAsRecent(drafts[0], post.nick, tops)) {
    const j = drafts.findIndex((d) => !sameAsRecent(d, post.nick, tops));
    if (j > 0) drafts = [drafts[j], ...drafts.filter((_, i) => i !== j)];
    else if (provider !== 'template') drafts = [...drafts.slice(1), drafts[0]]; // AI 초안은 그대로 두고 순서만 돌림
    else {
      for (let k = 0; k < 4; k++) {
        const alt = NBXC.compose(post, { callName: c.callName, relation: msg.relation, length: c.length, mood }, used).find((d) => !sameAsRecent(d, post.nick, tops));
        if (alt) { drafts = [alt, ...drafts.slice(0, 2)]; break; }
      }
    }
  }
  if (drafts.length) await rememberTop(drafts[0], post.nick);
  const copied = msg.copy === true ? await copyText(drafts[0].text) : false;
  if (key) await logMark(key, 'g');
  return { ok: true, drafts, provider, providerLabel: provider === 'template' ? '템플릿' : NBX.AI_PROVIDERS[provider].label, note, copied, stats: statsOf(await readLog()), mood: { tone: mood.tone, sub: mood.sub || '', label: mood.label, topicLabel: mood.tone === 'dark' ? '' : mood.topicLabel || '' }, prepared: fromPrepared };
}

async function openForComment(msg, sender) {
  if (!ID_RE.test(msg.blogId || '') || !NO_RE.test(String(msg.logNo || ''))) return { ok: false, error: 'bad-id' };
  if (!(await postAlive(msg.blogId, String(msg.logNo)))) return { ok: false, error: 'deleted' };
  const props = { url: `https://blog.naver.com/${msg.blogId}/${msg.logNo}`, active: true };
  if (sender.tab) { props.index = sender.tab.index + 1; props.openerTabId = sender.tab.id; props.windowId = sender.tab.windowId; }
  const tab = await chrome.tabs.create(props);
  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
  const J = await loadJobs();
  J[tab.id] = { blogId: msg.blogId, logNo: String(msg.logNo), title: cleanStr(msg.title, 150), nick: cleanStr(msg.nick, 30), relation: msg.relation === 'buddy' ? 'buddy' : 'other', at: Date.now() };
  saveJobs();
  logMark(postKeyOf(msg.blogId, msg.logNo), 'o');
  if (msg.next) prefetch(msg.next);
  return { ok: true, tabId: tab.id };
}

async function cmtHello(msg, sender) {
  const tabId = sender.tab && sender.tab.id;
  if (tabId == null) return { job: null };
  const J = await loadJobs();
  const job = J[tabId];
  if (!job || Date.now() - job.at > CMT_JOB_TTL) return { job: null };
  if (!job.any) {
    if (!msg.logNo || String(msg.logNo) !== job.logNo) return { job: null };
    if (msg.blogId && job.blogId && String(msg.blogId).toLowerCase() !== job.blogId.toLowerCase()) return { job: null };
  }
  // 한 번 쓰면 없앱니다: 같은 탭에서 다른 글로 옮기거나 뒤로 가도 저절로 다시 돌지 않습니다
  delete J[tabId];
  saveJobs();
  return { job: { ...job, blogId: job.any ? msg.blogId : job.blogId, logNo: job.any ? msg.logNo : job.logNo } };
}

// 이웃 새 글: 로그인한 크롬에서 네이버 "이웃새글" 목록을 읽습니다
function collectPosts(node, out, depth) {
  if (!node || depth > 7 || out.length >= 200) return out;
  if (Array.isArray(node)) { node.forEach((n) => collectPosts(n, out, depth + 1)); return out; }
  if (typeof node === 'object') {
    const blogId = node.blogId || node.domainIdOrBlogId || node.blogIdOrDomainId;
    if (node.logNo && typeof blogId === 'string') {
      const d = node.addDate ?? node.postDate ?? node.createdDate ?? node.regDate ?? node.addTimestamp;
      out.push({
        blogId, logNo: String(node.logNo),
        title: stripTags(node.title || node.titleWithInspectMessage || node.postTitle || node.subject || '').slice(0, 150),
        nick: stripTags(node.nickName || node.nickname || node.userNickName || node.blogNickName || '').slice(0, 30),
        blogName: stripTags(node.blogName || node.blogTitle || '').slice(0, 60),
        at: typeof d === 'number' ? d : (Date.parse(d) || null)
      });
      return out;
    }
    Object.values(node).forEach((v) => { if (v && typeof v === 'object') collectPosts(v, out, depth + 1); });
  }
  return out;
}
// 네이버는 이웃 피드 요청에 "어느 화면에서 불렀는지(Referer)"를 확인합니다. 확장이 보내는 이 요청에만
// 네이버 이웃 피드 화면 주소를 붙입니다(크롬의 요청 규칙 기능 — 다른 사이트·다른 요청은 건드리지 않음)
const FEED_RULES = [
  { id: 901, priority: 1, action: { type: 'modifyHeaders', requestHeaders: [{ header: 'referer', operation: 'set', value: 'https://m.blog.naver.com/FeedList.naver' }] },
    condition: { urlFilter: '||query.blog.naver.com/mweb/buddy-feed/', initiatorDomains: [chrome.runtime.id], resourceTypes: ['xmlhttprequest'] } },
  { id: 902, priority: 1, action: { type: 'modifyHeaders', requestHeaders: [{ header: 'referer', operation: 'set', value: 'https://section.blog.naver.com/BlogHome.naver?directoryNo=0&currentPage=1&groupId=0' }] },
    condition: { urlFilter: '||section.blog.naver.com/ajax/', initiatorDomains: [chrome.runtime.id], resourceTypes: ['xmlhttprequest'] } }
];
let rulesP = null;
function ensureFeedRules() {
  if (!rulesP) rulesP = chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: FEED_RULES.map((r) => r.id), addRules: FEED_RULES }).catch((e) => { rulesP = null; throw e; });
  return rulesP;
}

const unescapeHtml = (s) => stripTags(String(s == null ? '' : s));
const feedItem = (c) => ({
  blogId: c.blogIdOrDomainId || c.domainIdOrBlogId || c.blogId, logNo: String(c.logNo),
  title: unescapeHtml(c.title).slice(0, 150), nick: unescapeHtml(c.nickname || c.nickName).slice(0, 30),
  blogName: unescapeHtml(c.blogName).slice(0, 60), at: typeof c.addDate === 'number' ? c.addDate : (Date.parse(c.addDate) || null),
  commentOff: c.commentOn === false
});
const validItem = (x) => ID_RE.test(x.blogId || '') && NO_RE.test(x.logNo || '');

// ① 모바일 이웃 피드(카드) — 다음 쪽은 서버가 준 pagingParam으로 이어 받습니다
let feedCursor = null;
async function feedCards(more) {
  if (!more) feedCursor = { pagingParam: null, exposed: [] };
  else if (!feedCursor) feedCursor = ((await chrome.storage.session.get('nbxFeedCursor').catch(() => ({}))) || {}).nbxFeedCursor || null;
  if (!feedCursor) return { ok: false, error: 'nocursor' }; // 이어 받을 자리를 모르면 예전 방식(쪽 번호)으로
  if (more && !feedCursor.pagingParam) return { ok: false, error: 'end' };
  const body = { feedType: 'TOTAL', exposedContentKeys: feedCursor.exposed.slice(-60) };
  if (feedCursor.pagingParam) body.pagingParam = feedCursor.pagingParam;
  const r = await fetch('https://query.blog.naver.com/mweb/buddy-feed/ab/cards', {
    method: 'POST', credentials: 'include', cache: 'no-store',
    headers: { 'content-type': 'application/json', accept: 'application/json, text/plain, */*' }, body: JSON.stringify(body)
  });
  const text = await r.text();
  let j;
  try { j = JSON.parse(text.replace(/^\)\]\}',?\s*/, '')); } catch (_) { return { ok: false, error: /login|nidlogin|로그인/i.test(text) ? 'login' : 'cards:HTTP ' + r.status }; }
  if (!j || !j.isSuccess || !j.result) return { ok: false, error: 'cards:' + ((j && j.error && (j.error.code || j.error.message)) || 'HTTP ' + r.status) };
  const items = [];
  for (const c of j.result.cardList || []) {
    if (!c || c.cardType !== 'buddy_post' || !c.card || !c.card.logNo) continue; // 추천·광고 카드는 빼고 이웃 글만
    feedCursor.exposed.push({ type: 'POST', key: Number(c.card.logNo) });
    const it = feedItem(c.card);
    if (validItem(it)) items.push(it);
  }
  feedCursor.pagingParam = j.result.pagingParam || null;
  feedCursor.exposed = feedCursor.exposed.slice(-120);
  await chrome.storage.session.set({ nbxFeedCursor: feedCursor }).catch(() => {});
  return { ok: true, items, more: !!feedCursor.pagingParam };
}
// ② 이웃새글 화면이 쓰는 목록(예전 방식)
async function feedSection(page) {
  const r = await fetch(`https://section.blog.naver.com/ajax/BuddyPostList.naver?page=${page}&groupId=0`, { credentials: 'include', cache: 'no-store' });
  if (!r.ok) return { ok: false, error: 'section:HTTP ' + r.status };
  const text = (await r.text()).replace(/^\)\]\}',?\s*/, '');
  let j;
  try { j = JSON.parse(text); } catch (_) { return { ok: false, error: /login|nidlogin|로그인/i.test(text) ? 'login' : 'section:not-json' }; }
  const items = collectPosts(j, [], 0).filter(validItem);
  return items.length ? { ok: true, items, more: items.length >= 5 } : { ok: false, error: 'section:empty' };
}
let feedSource = null; // 한 번 성공한 방식을 다음 쪽에도 씁니다
const feedTrace = [];
async function buddyFeed(page) {
  const p = Math.max(1, Math.min(20, parseInt(page, 10) || 1));
  try { await ensureFeedRules(); } catch (e) { feedTrace.push('rules: ' + (e && e.message)); }
  if (p > 1 && !feedSource) feedSource = ((await chrome.storage.session.get('nbxFeedSource').catch(() => ({}))) || {}).nbxFeedSource || null;
  const tries = p > 1 && feedSource ? [feedSource, ...(feedSource === 'cards' ? ['section'] : [])] : ['cards', 'section'];
  const errors = [];
  for (const src of tries) {
    try {
      const r = src === 'cards' ? await feedCards(p > 1) : await feedSection(p);
      if (r.ok) {
        feedSource = src;
        chrome.storage.session.set({ nbxFeedSource: src }).catch(() => {});
        const seen = new Set();
        const items = r.items.filter((x) => { const k = x.blogId.toLowerCase() + '/' + x.logNo; if (seen.has(k)) return false; seen.add(k); return true; })
          .map((x) => ({ ...x, official: NBX.isOfficialBlog(x) })); // 공식 블로그 표시(목록에서는 기본으로 뺌)
        return { ok: true, items, page: p, more: r.more, source: src };
      }
      errors.push(r.error);
      if (r.error === 'end') return { ok: false, error: 'empty', page: p };
    } catch (e) { errors.push(src + ':' + String((e && e.message) || e)); }
  }
  feedTrace.splice(0, feedTrace.length, ...errors.slice(-6));
  return { ok: false, error: errors.includes('login') ? 'login' : 'fail', detail: errors.join(' | '), page: p };
}

// 키워드 노출 글: 네이버 블로그 검색 결과의 글 목록(제목·블로거)을 순서대로
async function searchPosts(q) {
  const res = await fetch(SEARCH_URL + encodeURIComponent(String(q).slice(0, 100)), { credentials: 'omit', cache: 'no-store' });
  if (!res.ok) return { ok: false, error: 'HTTP ' + res.status };
  const html = await res.text();
  const items = new Map();
  const names = {};
  const aRe = /<a\b([^>]*)>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = aRe.exec(html))) {
    const hm = m[1].match(/href=["']([^"']+)["']/i);
    if (!hm) continue;
    const href = decodeEnt(hm[1]);
    const text = stripTags(m[2]).replace(/\s+/g, ' ').trim();
    const pm = href.match(/^https?:\/\/(?:m\.)?blog\.naver\.com\/([A-Za-z0-9_-]{2,40})\/(\d{6,20})(?:[?#/]|$)/);
    if (pm) {
      const key = pm[1].toLowerCase() + '/' + pm[2];
      const it = items.get(key) || { blogId: pm[1], logNo: pm[2], title: '', tp: 0 };
      // 제목다운 글자(글자 4자 이상, 한글·영문 포함)를 고르고, class에 title이 들어간 링크를 우선합니다
      const ok = text.length >= 4 && /[가-힣A-Za-z]{2}/.test(text);
      const pri = ok ? (/class=["'][^"']*title/i.test(m[1]) ? 2 : 1) : 0;
      if (pri > it.tp) { it.title = text.slice(0, 120); it.tp = pri; }
      items.set(key, it);
      continue;
    }
    const bm = href.match(/^https?:\/\/(?:m\.)?blog\.naver\.com\/([A-Za-z0-9_-]{2,40})\/?(?:[?#]|$)/);
    if (bm && text && text.length <= 30 && !names[bm[1].toLowerCase()]) names[bm[1].toLowerCase()] = text;
  }
  const list = [...items.values()].slice(0, 30).map(({ tp, ...it }) => { const x = { ...it, nick: names[it.blogId.toLowerCase()] || '' }; x.official = NBX.isOfficialBlog(x); return x; });
  if (!list.length && !/검색결과가 없습니다|검색 결과가 없습니다/.test(html)) return { ok: false, error: 'unexpected-page' };
  return { ok: true, items: list };
}

async function cmtLogFor(keys) {
  const log = await readLog();
  const marks = {};
  (Array.isArray(keys) ? keys.slice(0, 200) : []).forEach((k) => { if (typeof k === 'string' && log.posts[k]) marks[k] = log.posts[k]; });
  return { stats: statsOf(log), marks };
}

// (예전 시험판이 chrome.storage.local에 둔 키가 있으면 보관함으로 옮기고 지웁니다)
chrome.storage.local.get('nbxAIKeys').then(async (r) => {
  if (r && r.nbxAIKeys && typeof r.nbxAIKeys === 'object') { await NBXKeys.setAll({ ...(await NBXKeys.getAll()), ...r.nbxAIKeys }); await chrome.storage.local.remove('nbxAIKeys'); }
}).catch(() => {});
async function aiTest(provider) {
  if (!NBX.AI_PROVIDERS[provider]) return { ok: false, error: '알 수 없는 AI' };
  const s = await getSettings();
  const apiKey = (await getKeys())[provider];
  if (!apiKey) return { ok: false, error: 'API 키를 먼저 넣어 주세요' };
  try {
    const text = await callAI(provider, apiKey, NBX.modelOf(s.cmt, provider), '너는 연결 확인용 도우미다. JSON 하나만 출력한다.', '{"comments":["연결 확인 완료"]} 를 그대로 출력해.');
    const list = NBXC.parseDrafts(text);
    return { ok: true, sample: list[0] || cleanStr(text, 60) };
  } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
}

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (sender.id !== chrome.runtime.id || !msg || msg.target === 'nbx-offscreen' || typeof msg.type !== 'string' || !msg.type.startsWith('nbx-cmt') && msg.type !== 'nbx-ai-test') return false;
  const run = (p) => { p.then(send, (e) => send({ ok: false, error: String((e && e.message) || e) })); return true; };
  switch (msg.type) {
    case 'nbx-cmt-open': return run(openForComment(msg, sender));
    case 'nbx-cmt-hello': return run(cmtHello(msg, sender));
    case 'nbx-cmt-generate': return run(cmtGenerate(msg));
    case 'nbx-cmt-copy': return run(copyText(msg.text).then((ok) => ({ ok })));
    case 'nbx-cmt-posted': {
      const key = postKeyOf(msg.blogId, msg.logNo);
      if (sender.tab && !msg.hold) queueOnPosted(sender.tab.id, key); // hold: 서로이웃 신청 결과를 기다렸다가 넘어감
      return run(withLog((log) => {
        const now = Date.now();
        const e = log.posts[key] || {};
        if (key && e.p && now - e.p < 5000) return; // 두 번 누름은 한 번으로
        if (key) { e.p = now; e.t = now; log.posts[key] = e; }
        log.done.push(now);
      }).then(readLog).then((log) => ({ ok: true, stats: statsOf(log) })));
    }
    case 'nbx-cmt-here': {
      const tabId = sender.tab && sender.tab.id;
      if (tabId == null) return false;
      return run(loadJobs().then((J) => {
        J[tabId] = { any: true, relation: 'other', at: Date.now() };
        saveJobs();
        chrome.tabs.sendMessage(tabId, { type: 'nbx-cmt-start' }).catch(() => {});
        return { ok: true };
      }));
    }
    case 'nbx-cmt-buddy': return run(buddyFeed(msg.page));
    case 'nbx-cmt-search': return typeof msg.q === 'string' && msg.q.trim() ? run(searchPosts(msg.q.trim())) : false;
    case 'nbx-cmt-log': return run(cmtLogFor(msg.keys));
    case 'nbx-cmt-alive': return run(aliveCheck(msg.items));
    case 'nbx-cmt-rewrite-open': {
      if (!ID_RE.test(msg.blogId || '') || !NO_RE.test(String(msg.logNo || ''))) return false;
      const q = new URLSearchParams({ b: msg.blogId, n: String(msg.logNo), s: msg.status === 'warn' ? 'warn' : 'miss', r: String(Number(msg.rank) || ''), t: cleanStr(msg.tag, 20) });
      // 설치 폴더에 화면 파일이 빠져 있으면(업데이트가 일부만 적용된 경우) 빠진 파일을 다시 채우는 화면을 엽니다
      return run(fetch(chrome.runtime.getURL('rewrite.html'), { cache: 'no-store' }).then((r) => r.ok, () => false).then(async (has) => {
        if (has) { await chrome.tabs.create({ url: chrome.runtime.getURL('rewrite.html?' + q) }); return { ok: true }; }
        if (hasFolderUpdater()) await chrome.tabs.create({ url: chrome.runtime.getURL('update.html?repair=1') });
        return { ok: false, error: 'missing', repair: hasFolderUpdater() };
      }));
    }
    case 'nbx-cmt-rewrite': return run(rewritePost(msg));
    case 'nbx-ai-test': return run(aiTest(msg.provider));
    case 'nbx-cmt-queue-start': return run(queueStart(msg, sender));
    case 'nbx-cmt-queue-next': return run(queueAdvance('skip', sender.tab && sender.tab.id));
    case 'nbx-cmt-queue-now': return run(paceNext(!!msg.force));
    case 'nbx-cmt-queue-resume': return run(queueResume());
    case 'nbx-cmt-queue-stop': return run(queueStop('사용자가 멈춤'));
    case 'nbx-cmt-queue-state': return run(getQueue().then(viewOf));
    case 'nbx-cmt-nb-open': return run(openBuddy({ blogId: msg.blogId, nick: msg.nick }, { origin: sender.tab ? sender.tab.id : null, hold: !!msg.hold }));
    case 'nbx-cmt-nb-hello': return run(buddyHello(sender, msg));
    case 'nbx-cmt-nb-filled': return run(buddyFilled(sender, msg));
    case 'nbx-cmt-nb-step': return run(buddyStep(sender, msg));
    case 'nbx-cmt-nb-stop': return run(buddyStop(sender));
    case 'nbx-cmt-nb-done': {
      const ok = ['mutual', 'follow', 'already', 'fail'].includes(msg.result);
      return ok && sender.tab ? run(buddyResult(sender.tab.id, msg.result, sender.tab.windowId)) : false;
    }
    case 'nbx-cmt-queue-posted': return sender.tab ? run(queueOnPosted(sender.tab.id, postKeyOf(msg.blogId, msg.logNo), 900)) : false;
    default: return false;
  }
});

// ───────────── AI 키 쉽게 연결 ─────────────
// · 키 받기 도우미: 키 만드는 화면(AI Studio 등)을 새 탭으로 열고 그 화면 위에 안내 줄을 띄웁니다.
//   키 옆 '복사'를 누르거나 안내 줄에 붙여 넣으면 키를 알아보고 저장한 뒤 바로 연결을 확인합니다.
// · 어디에 붙여 넣은 키든 모양으로 어느 회사 키인지 알아봅니다(제미나이 AIza…, 클로드 sk-ant-…, GPT sk-…, OpenRouter sk-or-…).
// 키는 확장 전용 보관함에만 두며, 키 화면과 네이버 화면의 스크립트는 읽을 수 없습니다.
const pageMatches = (url, pats) => typeof url === 'string' && (pats || []).some((p) => toRe(p).test(url));
async function helperTabs() { const r = await chrome.storage.session.get('nbxKeyTabs').catch(() => ({})); return (r && r.nbxKeyTabs) || {}; }
async function setHelperTab(tabId, v) {
  const m = await helperTabs();
  if (v) m[tabId] = v; else if (m[tabId]) delete m[tabId]; else return;
  await chrome.storage.session.set({ nbxKeyTabs: m }).catch(() => {});
}
// 안내 줄에 넣을 내용(회사마다 버튼 이름이 달라 단계 안내를 따로 둡니다)
const KEY_STEPS = {
  gemini: ['오른쪽 위 <b>API 키 만들기(Create API key)</b>를 누르세요', '프로젝트는 처음 나오는 것 그대로 두고 만들기를 누르세요', '만들어진 키 옆 <b>복사</b> 버튼을 누르면 토이블록이 바로 알아보고 연결해요'],
  claude: ['<b>Create key</b>를 누르고 이름에 토이블록을 적으세요', '만료(Expiration)는 <b>Never</b>, 워크스페이스는 <b>Default</b>를 고르세요', '만든 키의 <b>Copy</b>를 누르면 토이블록이 바로 알아보고 연결해요 · 결제 크레딧이 있어야 써요'],
  openai: ['<b>+ Create new secret key</b>를 누르세요', '이름에 토이블록을 적고 <b>Create secret key</b>를 누르세요', '나온 키의 <b>Copy</b>를 누르면 토이블록이 바로 알아보고 연결해요 · 결제 등록이 있어야 써요'],
  openrouter: ['<b>Create API Key</b>를 누르세요', '이름에 토이블록을 적고 만들기를 누르세요', '나온 키를 복사하면 토이블록이 바로 알아보고 연결해요 · 무료 모델은 하루 50회']
};
async function openKeyHelper(provider) {
  const info = NBX.AI_PROVIDERS[provider];
  if (!info || !info.console) return { ok: false, error: '알 수 없는 AI' };
  const tab = await chrome.tabs.create({ url: info.keyUrl });
  await setHelperTab(tab.id, { provider, at: Date.now() });
  return { ok: true, tabId: tab.id };
}
async function injectHelper(tabId, url) {
  const h = (await helperTabs())[tabId];
  const info = h && NBX.AI_PROVIDERS[h.provider];
  if (!info || !pageMatches(url, info.console)) return false;
  const target = { tabId };
  const cfg = { provider: h.provider, label: info.label, steps: KEY_STEPS[h.provider] || [], re: Object.fromEntries(NBX.KEY_PROVIDERS.map((p) => [p, NBX.AI_PROVIDERS[p].keyRe.source])) };
  try {
    await chrome.scripting.executeScript({ target, func: (c) => { globalThis.__nbxKeyCfg = c; }, args: [cfg] });
    await chrome.scripting.executeScript({ target, files: ['keyhelper.js'] });
    await chrome.scripting.executeScript({ target, world: 'MAIN', files: ['keyhook.js'] });
    return true;
  } catch (_) { return false; } // 키 화면 접근을 허용하지 않았으면 안내 줄 없이 키 화면만 열립니다
}
chrome.tabs.onUpdated.addListener((tabId, ch, tab) => {
  if (ch.status !== 'complete' || !tab || !tab.url) return;
  helperTabs().then((m) => { if (m[tabId]) injectHelper(tabId, tab.url); });
});
chrome.tabs.onRemoved.addListener((tabId) => { setHelperTab(tabId, null); });

let keyQ = Promise.resolve();
// 키를 저장하고 그 AI를 댓글 AI로 고른 뒤 연결을 확인합니다(한 번에 하나씩)
function saveKey(text, want) {
  const p = keyQ.then(async () => {
    const found = NBX.detectKey(text);
    let provider = found && found.provider, key = found && found.key;
    // 모양으로 못 알아본 키는, 어느 AI 키인지 정해 준 경우에만 그대로 받습니다
    if (!found && NBX.KEY_PROVIDERS.includes(want)) { const t = String(text || '').trim().replace(/^["'\s]+|["'\s]+$/g, ''); if (/^[A-Za-z0-9._\-]{20,300}$/.test(t)) { provider = want; key = t; } }
    if (!provider) return { ok: false, error: 'AI 키 모양이 아니에요. 키 전체를 복사했는지 확인해 주세요' };
    const all = await getKeys();
    const same = all[provider] === key;
    all[provider] = key;
    await NBXKeys.setAll(all);
    const s = await getSettings();
    s.cmt.provider = provider;
    if (provider === 'openrouter' && !s.cmt.models.openrouter) s.cmt.models.openrouter = await pickOpenRouterModel();
    await chrome.storage.sync.set({ nbx: s });
    const test = await aiTest(provider);
    const info = NBX.AI_PROVIDERS[provider];
    const ev = { provider, label: info.label, masked: NBX.maskKey(key), same, ok: !!test.ok, error: test.error || '', at: Date.now() };
    await chrome.storage.local.set({ nbxKeyEvent: ev }).catch(() => {});
    return { ok: true, ...ev, test };
  });
  keyQ = p.catch(() => {});
  return p;
}
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (sender.id !== chrome.runtime.id || !msg || typeof msg.type !== 'string' || !msg.type.startsWith('nbx-key-')) return false;
  const run = (p) => { p.then(send, (e) => send({ ok: false, error: String((e && e.message) || e) })); return true; };
  const fromExtPage = typeof sender.url === 'string' && sender.url.startsWith(chrome.runtime.getURL(''));
  switch (msg.type) {
    case 'nbx-key-helper-open': return fromExtPage ? run(openKeyHelper(msg.provider)) : false;
    case 'nbx-key-save': return fromExtPage && typeof msg.text === 'string' ? run(saveKey(msg.text, msg.provider)) : false;
    case 'nbx-key-pick-model': return fromExtPage ? run(pickOpenRouterModel().then((model) => ({ ok: true, model }))) : false;
    case 'nbx-key-found': {
      // 키 화면의 안내 줄에서 온 것만 받습니다(도우미로 연 탭 + 그 회사 키 화면 주소)
      const tabId = sender.tab && sender.tab.id;
      if (tabId == null || typeof msg.text !== 'string') return false;
      return run(helperTabs().then((m) => {
        const h = m[tabId];
        const info = h && NBX.AI_PROVIDERS[h.provider];
        if (!info || !pageMatches(sender.url || (sender.tab && sender.tab.url), info.console)) return { ok: false, error: '키 받기 도우미로 연 화면이 아니에요' };
        return saveKey(msg.text.slice(0, 5000), h.provider);
      }));
    }
    case 'nbx-key-helper-close': {
      const tabId = sender.tab && sender.tab.id;
      if (tabId == null) return false;
      return run(helperTabs().then(async (m) => { if (m[tabId]) { await chrome.tabs.remove(tabId).catch(() => {}); } return { ok: true }; }));
    }
    default: return false;
  }
});

// ───────────── 연속 소통(반자동) ─────────────
// 목록의 글을 한 탭에서 차례로 엽니다. 글마다 댓글을 입력칸에 채워 두고, 사용자가 등록하면(네이버 [등록] 또는 카드의
// [등록 + 서로이웃 신청]) 다음 글로 넘어갑니다. 이웃 추가 창은 사용자가 버튼을 누른 블로그에만 열고, 그 창에서만
// 서로이웃 신청을 끝까지 진행합니다. 사용자가 누르지 않은 글·블로그에는 아무것도 보내지 않습니다.
const QUEUE_MAX = 50;          // 한 번에 차례로 열 글 수
const QUEUE_NEXT_MS = 2500;    // 등록 뒤 다음 글로 넘어가기까지
const HOUR_PAUSE = 20;         // 최근 1시간 댓글이 이만큼이면 잠시 멈춤
const BUDDY_DAY_MAX = 50;      // 하루에 여는 이웃 추가 창 수
const BUDDY_AGAIN_DAYS = 30;   // 한 번 신청 창을 연 블로그는 이 기간 동안 다시 열지 않음
// 천천히 소통: 1시간 동안 목표 개수만큼, 등록할 때마다 정한 쉬는 시간을 두고 다음 글을 엽니다(등록은 사용자가 직접)
const PACE_TARGETS = [8, 10, 12, 15, 20];
const PACE_REST_MIN = 60e3, PACE_REST_MAX = 90e3;   // 등록 뒤 쉬는 시간: 1분~1분 30초 사이(글마다 다르게)
const PACE_HOUR = 60 * 60e3;
const PACE_ALARM = 'nbx-pace';
const dayKey = (t = Date.now()) => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

async function getQueue() { const r = await chrome.storage.session.get('nbxQueue').catch(() => ({})); return (r && r.nbxQueue) || null; }
function viewOf(q) {
  if (!q) return { state: 'none' };
  const v = { state: q.state, i: q.i, total: q.items.length, done: q.done, skipped: q.skipped, dead: q.dead || 0, relation: q.relation, note: q.note || '', buddy: q.buddy, at: Date.now() };
  if (q.pace) v.pace = { target: q.pace.target, restMin: Math.round(PACE_REST_MIN / 1000), restMax: Math.round(PACE_REST_MAX / 1000), startAt: q.pace.startAt, endAt: q.pace.endAt, rest: q.rest ? { until: q.rest.until, ms: q.rest.ms } : null };
  return v;
}
async function setQueue(q) {
  await chrome.storage.session.set({ nbxQueue: q }).catch(() => {});
  const v = viewOf(q);
  await chrome.storage.local.set({ nbxQueueView: v }).catch(() => {}); // 패널(네이버 화면)이 진행 상황을 볼 수 있게
  if (q && q.tabId != null) chrome.tabs.sendMessage(q.tabId, { type: 'nbx-queue-state', view: v }).catch(() => {});
  return v;
}
let queueQ = Promise.resolve();
const queued = (fn) => { const p = queueQ.then(fn, fn); queueQ = p.catch(() => {}); return p; };

const postUrl = (it) => `https://blog.naver.com/${it.blogId}/${it.logNo}`;
// 지금 차례부터 지워지지 않은 글을 찾습니다(지워진 글은 건너뜀으로 셉니다). 남은 글이 없으면 false
async function nextAlive(q) {
  while (q.i < q.items.length && !(await postAlive(q.items[q.i].blogId, q.items[q.i].logNo))) { q.skipped++; q.dead = (q.dead || 0) + 1; q.i++; }
  return q.i < q.items.length;
}
async function queueJob(tabId, q) {
  const it = q.items[q.i];
  const J = await loadJobs();
  J[tabId] = { blogId: it.blogId, logNo: it.logNo, title: it.title, nick: it.nick, relation: it.relation, at: Date.now(), queue: { n: q.i + 1, total: q.items.length } };
  saveJobs();
  logMark(postKeyOf(it.blogId, it.logNo), 'o');
}
function queueStart(msg, sender) {
  return queued(async () => {
    const relation = msg.relation === 'buddy' ? 'buddy' : 'other';
    const items = (Array.isArray(msg.items) ? msg.items : []).filter((x) => x && ID_RE.test(x.blogId || '') && NO_RE.test(String(x.logNo || '')))
      .slice(0, QUEUE_MAX).map((x) => ({ blogId: x.blogId, logNo: String(x.logNo), title: cleanStr(x.title, 150), nick: cleanStr(x.nick, 30), relation }));
    if (!items.length) return { ok: false, error: 'empty' };
    const s = await getSettings();
    const q = { id: Date.now(), items, i: 0, done: 0, skipped: 0, dead: 0, relation, buddy: relation === 'other' && s.cmt.buddyAuto, state: 'run', note: '', tabId: null };
    if (msg.pace) {
      const target = PACE_TARGETS.includes(Number(msg.pace.target)) ? Number(msg.pace.target) : 12;
      q.pace = { target, startAt: Date.now(), endAt: Date.now() + PACE_HOUR };
      chrome.alarms.clear(PACE_ALARM).catch(() => {});
    }
    if (!(await nextAlive(q))) return { ok: false, error: 'all-deleted', dead: q.dead };
    const props = { url: postUrl(items[q.i]), active: true };
    if (sender.tab) { props.index = sender.tab.index + 1; props.openerTabId = sender.tab.id; props.windowId = sender.tab.windowId; }
    const tab = await chrome.tabs.create(props);
    q.tabId = tab.id;
    await queueJob(tab.id, q);
    await setQueue(q);
    if (items[q.i + 1]) prefetch(items[q.i + 1]);
    return { ok: true, total: items.length, dead: q.dead };
  });
}
// 다음 글로: reason = 'posted'(등록함) | 'skip'(건너뜀)
function queueAdvance(reason, fromTab, key) {
  return queued(async () => {
    const q = await getQueue();
    if (!q || q.state !== 'run') return { ok: false, error: 'not-running' };
    if (fromTab != null && fromTab !== q.tabId) return { ok: false, error: 'other-tab' };
    if (key && (!q.items[q.i] || postKeyOf(q.items[q.i].blogId, q.items[q.i].logNo) !== key)) return { ok: false, error: 'moved' };
    if (q.rest) { reason = 'posted'; q.rest = null; chrome.alarms.clear(PACE_ALARM).catch(() => {}); } // 쉬는 중이면 이 글은 이미 등록한 글
    if (reason === 'posted') q.done++; else q.skipped++;
    q.i++;
    if (q.pace && q.done >= q.pace.target) { q.state = 'done'; q.note = `천천히 소통 목표 ${q.pace.target}개를 채웠어요. 오늘도 수고했어요!`; return { ok: true, view: await setQueue(q) }; }
    if (q.pace && Date.now() >= q.pace.endAt) { q.state = 'done'; q.note = '1시간이 지나 천천히 소통을 마쳤어요.'; return { ok: true, view: await setQueue(q) }; }
    if (!(await nextAlive(q))) { q.state = 'done'; q.note = (q.pace ? '목록의 글을 모두 돌았어요. ' : '') + (q.dead ? `삭제된 글 ${q.dead}개는 건너뛰었어요.` : ''); return { ok: true, view: await setQueue(q) }; }
    const st = statsOf(await readLog());
    if (st.hour >= HOUR_PAUSE) {
      q.state = 'paused';
      q.note = `최근 1시간에 댓글 ${st.hour}개를 남겼어요. 잠시 쉬었다가 [이어 하기]를 눌러 주세요.`;
      return { ok: true, view: await setQueue(q) };
    }
    await openCurrent(q);
    return { ok: true, view: viewOf(q) };
  });
}
async function openCurrent(q) {
  try { await chrome.tabs.get(q.tabId); }
  catch (_) { const t = await chrome.tabs.create({ url: postUrl(q.items[q.i]), active: true }); q.tabId = t.id; await queueJob(t.id, q); await setQueue(q); return; }
  await queueJob(q.tabId, q);
  await setQueue(q);
  await chrome.tabs.update(q.tabId, { url: postUrl(q.items[q.i]), active: true });
  if (q.items[q.i + 1]) prefetch(q.items[q.i + 1]);
}
function queueResume() {
  return queued(async () => {
    const q = await getQueue();
    if (!q || q.state !== 'paused') return { ok: false, error: 'not-paused' };
    q.state = 'run'; q.note = '';
    await openCurrent(q);
    return { ok: true, view: viewOf(q) };
  });
}
function queueStop(why) {
  return queued(async () => {
    const q = await getQueue();
    if (!q) return { ok: true, view: viewOf(null) };
    q.state = 'stopped'; q.note = why || ''; q.rest = null;
    chrome.alarms.clear(PACE_ALARM).catch(() => {});
    const v = await setQueue(q);
    await chrome.storage.session.remove('nbxQueue').catch(() => {});
    return { ok: true, view: v };
  });
}
// 연속 소통 탭에서 사용자가 등록하면(댓글 도우미가 실제로 올라간 것을 확인한 뒤 알림) 잠시 뒤 다음 글로.
// 서로이웃 신청도 함께 눌렀으면 카드가 신청 결과를 받은 뒤 'nbx-cmt-queue-posted'로 다시 알려 줍니다.
async function queueOnPosted(tabId, key, ms = QUEUE_NEXT_MS) {
  const q = await getQueue();
  if (!q || q.state !== 'run' || q.tabId !== tabId) return { ok: false };
  const it = q.items[q.i];
  if (!it || postKeyOf(it.blogId, it.logNo) !== key) return { ok: false };
  if (q.pace) return paceRest(tabId, key);
  setTimeout(() => { queueAdvance('posted', tabId, key); }, ms); // 그사이 건너뛰기로 이미 넘어갔으면 다시 넘기지 않음
  return { ok: true };
}
// 천천히 소통: 등록 뒤 쉬는 시간을 두고 다음 글로(목표를 채웠거나 1시간이 지났으면 바로 마침)
function paceRest(tabId, key) {
  return queued(async () => {
    const q = await getQueue();
    if (!q || !q.pace || q.state !== 'run' || q.tabId !== tabId || q.rest) return { ok: false };
    const it = q.items[q.i];
    if (!it || postKeyOf(it.blogId, it.logNo) !== key) return { ok: false };
    const now = Date.now();
    if (q.done + 1 >= q.pace.target || now >= q.pace.endAt || q.i + 1 >= q.items.length) { setTimeout(() => queueAdvance('posted', tabId, key), 1500); return { ok: true, last: true }; }
    const pick = PACE_REST_MIN + Math.round(Math.random() * (PACE_REST_MAX - PACE_REST_MIN) / 1000) * 1000;
    const ms = Math.min(pick, Math.max(0, q.pace.endAt - now));
    q.rest = { until: now + ms, ms, key, tabId };
    await setQueue(q);
    chrome.alarms.create(PACE_ALARM, { when: q.rest.until });
    if (q.items[q.i + 1]) prefetch(q.items[q.i + 1]);
    return { ok: true, rest: ms };
  });
}
// 쉬는 시간이 끝났을 때(알람) · 카드에서 [지금 다음 글로]를 눌렀을 때
async function paceNext(force) {
  const q = await getQueue();
  if (!q || !q.rest || q.state !== 'run') return { ok: false, error: 'no-rest' };
  if (!force && Date.now() < q.rest.until - 1500) return { ok: false, error: 'early', until: q.rest.until };
  return queueAdvance('posted', q.rest.tabId, q.rest.key);
}
chrome.alarms.onAlarm.addListener((a) => { if (a.name === PACE_ALARM) paceNext(false); });
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const q = await getQueue();
  if (q && q.tabId === tabId && (q.state === 'run' || q.state === 'paused')) queueStop('연속 소통 탭을 닫아 멈췄어요');
});

// ── 이웃 추가 창(네이버 BuddyAdd) ──
// 사용자가 버튼(카드의 [등록 + 서로이웃 신청]·[＋ 서로이웃 신청], 목록의 ＋이웃, 블로그의 이웃추가)을 누른 블로그에만 엽니다.
// 그렇게 연 창은 서로이웃을 고르고 신청 메시지를 채운 뒤 [다음]·[확인]까지 진행합니다(설정에서 끄면 채워 두기만).
const BUDDY_STEP_MAX = 5;      // 한 창에서 확장이 누르는 버튼 수(다음·확인 등) — 화면이 예상과 달라도 계속 누르지 않게
async function buddyLog() {
  const r = await chrome.storage.local.get('nbxBuddyLog').catch(() => ({}));
  const L = (r && r.nbxBuddyLog) || {};
  L.asked = L.asked || {};
  L.sent = L.sent || {};
  if (L.day !== dayKey()) { L.day = dayKey(); L.n = 0; }
  const cut = Date.now() - BUDDY_AGAIN_DAYS * 864e5;
  Object.keys(L.asked).forEach((k) => { if (L.asked[k] < cut) delete L.asked[k]; });
  Object.keys(L.sent).forEach((k) => { if (!L.sent[k] || L.sent[k].at < cut) delete L.sent[k]; });
  return L;
}
async function buddyJobs() {
  const r = await chrome.storage.session.get('nbxBuddyJobs').catch(() => ({}));
  const jobs = (r && r.nbxBuddyJobs) || {};
  Object.keys(jobs).forEach((k) => { if (Date.now() - jobs[k].at > 30 * 60e3) delete jobs[k]; });
  return jobs;
}
const saveBuddyJobs = (jobs) => chrome.storage.session.set({ nbxBuddyJobs: jobs }).catch(() => {});
// 오늘 몇 개 열었는지 세고, 서로이웃 신청을 자동으로 마칠지 정합니다
async function buddyCount(blogId) {
  const L = await buddyLog();
  const over = L.n >= BUDDY_DAY_MAX;
  if (!over) { L.n++; L.asked[String(blogId).toLowerCase()] = Date.now(); }
  await chrome.storage.local.set({ nbxBuddyLog: L }).catch(() => {});
  return { over, n: L.n };
}
// 이웃 추가 창 기록은 한 줄로 세워 처리합니다(창 둘이 동시에 열려도 서로 덮어쓰지 않고, 창이 먼저 물어봐도 기록이 끝난 뒤에 답함)
let buddyQ = Promise.resolve();
const bq = (fn) => { const p = buddyQ.then(fn, fn); buddyQ = p.catch(() => {}); return p; };
function openBuddy(it, opts = {}) { return bq(() => openBuddyNow(it, opts)); }
async function openBuddyNow(it, opts = {}) {
  if (!ID_RE.test(it.blogId || '')) return { ok: false, error: 'bad-id' };
  const L = await buddyLog();
  if (L.n >= BUDDY_DAY_MAX) return { ok: false, error: 'day-limit', n: L.n };
  const s = await getSettings();
  const nick = cleanStr(it.nick, 30);
  const msg = NBX.buddyMessage(s.cmt.buddyMsg, nick, (n) => NBXC.callable(n));
  const win = await chrome.windows.create({ url: `https://blog.naver.com/BuddyAdd.naver?blogId=${encodeURIComponent(it.blogId)}`, type: 'popup', width: 520, height: 680, focused: true });
  const tabId = win && win.tabs && win.tabs[0] && win.tabs[0].id;
  const jobs = await buddyJobs();
  if (tabId != null) jobs[tabId] = { blogId: it.blogId, nick, msg, type: s.cmt.buddyType, at: Date.now(), auto: s.cmt.buddyOneClick !== false, steps: 0, origin: opts.origin == null ? null : opts.origin, hold: !!opts.hold };
  await saveBuddyJobs(jobs);
  const c = await buddyCount(it.blogId);
  return { ok: true, windowId: win.id, tabId, today: c.n, auto: s.cmt.buddyOneClick !== false };
}
// 이웃 추가 창의 도우미가 처음 묻는 것: 이 창에서 무엇을 할지.
// 토이블록이 연 창이 아니면(블로그 화면의 이웃추가 버튼을 사용자가 누른 창) 설정이 켜져 있을 때만 같은 방식으로 돕습니다.
function buddyHello(sender, msg) { return bq(() => buddyHelloNow(sender, msg)); }
async function buddyHelloNow(sender, msg) {
  const tab = sender.tab;
  const tabId = tab && tab.id;
  if (tabId == null || !/^https:\/\/(m\.)?blog\.naver\.com\//.test(sender.url || '')) return { ok: false };
  const jobs = await buddyJobs();
  let j = jobs[tabId];
  if (!j) {
    const s = await getSettings();
    const blogId = String((msg && msg.blogId) || '');
    if (!s.cmt.buddyOneClick || !ID_RE.test(blogId)) return { ok: false };
    // 신청까지 저절로 마치는 것은 '그 블로그 화면에서 연 창'(블로그의 이웃추가 버튼)일 때만입니다.
    // 다른 사이트나 링크가 연 이웃 추가 창은 메시지만 채워 두고, 신청은 사용자가 직접 누릅니다.
    let nick = '', sameBlog = false;
    if (tab.openerTabId != null) {
      const opener = await chrome.tabs.get(tab.openerTabId).catch(() => null);
      let openerBlog = '';
      try { const u = new URL((opener && opener.url) || ''); if (/^(m\.)?blog\.naver\.com$/.test(u.hostname)) openerBlog = u.searchParams.get('blogId') || (u.pathname.match(/^\/([A-Za-z0-9_-]{2,40})(?:\/|$)/) || [])[1] || ''; } catch (_) {}
      const who = openerBlog ? await chrome.tabs.sendMessage(tab.openerTabId, { type: 'nbx-cmt-whois' }).catch(() => null) : null;
      if (who && who.blogId && String(who.blogId).toLowerCase() === blogId.toLowerCase()) { nick = cleanStr(who.nick, 30); sameBlog = true; }
      if (openerBlog && openerBlog.toLowerCase() === blogId.toLowerCase()) sameBlog = true;
    }
    const c = sameBlog ? await buddyCount(blogId) : { over: false };
    j = { blogId, nick, msg: NBX.buddyMessage(s.cmt.buddyMsg, nick, (n) => NBXC.callable(n)), type: s.cmt.buddyType, at: Date.now(), auto: sameBlog && !c.over, steps: 0, origin: tab.openerTabId == null ? null : tab.openerTabId, native: true, over: c.over };
    jobs[tabId] = j;
    await saveBuddyJobs(jobs);
  }
  return { ok: true, blogId: j.blogId, nick: j.nick, msg: j.msg, type: j.type, auto: !!j.auto && !j.result && !j.stopped, over: !!j.over, result: j.result || '', done: j.picked || '' };
}
function buddyFilled(sender, msg) { return bq(() => buddyFilledNow(sender, msg)); }
async function buddyFilledNow(sender, msg) {
  const tabId = sender.tab && sender.tab.id;
  const jobs = await buddyJobs();
  if (tabId == null || !jobs[tabId]) return { ok: false };
  jobs[tabId].filled = !!msg.filled; jobs[tabId].radio = !!msg.picked; // picked(서로이웃/이웃 결과)와 따로 둡니다
  await saveBuddyJobs(jobs);
  return { ok: true };
}
// 확장이 창 안의 버튼(다음·확인 등)을 누르기 전에 묻습니다: 사용자가 누른 창이고, 아직 몇 번 안 눌렀을 때만
function buddyStep(sender, msg) { return bq(() => buddyStepNow(sender, msg)); }
async function buddyStepNow(sender, msg) {
  const tabId = sender.tab && sender.tab.id;
  const jobs = await buddyJobs();
  const j = tabId == null ? null : jobs[tabId];
  if (!j || !j.auto || j.result || j.stopped) return { ok: false };
  if (j.steps >= BUDDY_STEP_MAX) return { ok: false, error: 'too-many' };
  j.steps++; j.lastStep = cleanStr(msg && msg.label, 20);
  if (msg && (msg.picked === 'mutual' || msg.picked === 'follow')) j.picked = msg.picked; // 다음 화면에서 결과(서로이웃/이웃)를 알 수 있게
  await saveBuddyJobs(jobs);
  return { ok: true, step: j.steps };
}
function buddyStop(sender) { return bq(() => buddyStopNow(sender)); }
async function buddyStopNow(sender) {
  const tabId = sender.tab && sender.tab.id;
  const jobs = await buddyJobs();
  if (tabId == null || !jobs[tabId]) return { ok: false };
  jobs[tabId].stopped = true;
  await saveBuddyJobs(jobs);
  return { ok: true };
}
// 결과: mutual(서로이웃 신청 보냄) · follow(이웃으로 추가) · already(이미 이웃·신청 중) · closed(완료 화면 전에 창이 닫힘) · fail
function buddyResult(tabId, result, windowId) { return bq(() => buddyResultNow(tabId, result, windowId)); }
async function buddyResultNow(tabId, result, windowId) {
  const jobs = await buddyJobs();
  const j = jobs[tabId];
  if (!j || j.result) return { ok: false };
  j.result = result;
  await saveBuddyJobs(jobs);
  if (result === 'mutual' || result === 'follow' || result === 'already') {
    const L = await buddyLog();
    L.sent[String(j.blogId).toLowerCase()] = { r: result, at: Date.now() };
    await chrome.storage.local.set({ nbxBuddyLog: L }).catch(() => {});
  }
  const note = { type: 'nbx-nb-result', blogId: j.blogId, result, hold: !!j.hold };
  if (j.origin != null) chrome.tabs.sendMessage(j.origin, note).catch(() => {});
  chrome.storage.local.set({ nbxBuddyLast: { blogId: j.blogId, result, at: Date.now() } }).catch(() => {});
  // 신청을 마친 창은 잠시 결과를 보여 준 뒤 닫습니다(팝업 창 하나짜리일 때만)
  if (windowId != null && result !== 'fail' && result !== 'closed') {
    setTimeout(async () => {
      try { const w = await chrome.windows.get(windowId, { populate: true }); if (w.type === 'popup' && w.tabs.length === 1) await chrome.windows.remove(windowId); } catch (_) {}
    }, 1600);
  }
  return { ok: true };
}
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const jobs = await buddyJobs();
  const j = jobs[tabId];
  if (j && !j.result) await buddyResult(tabId, j.steps ? 'closed' : 'cancel', null);
});
